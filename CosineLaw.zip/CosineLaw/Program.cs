﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CosineLaw
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaring variables & User inputs lengths and angle

            Console.WriteLine("Enter the triangle side A");
            double SideA = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the triangle side B");
            double SideB = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the triangle Angle C in degrees");
            double AngleC = double.Parse(Console.ReadLine());

            //Calculations with Cosine Law

            double Radian = AngleC * (Math.PI / 180);
            double SideC = Math.Sqrt(Math.Pow(SideA, 2) + Math.Pow(SideB, 2) - 2 * SideA * SideB * Math.Cos(Radian));

            //Rounds answer to 2 decimal places

            SideC = Math.Round(SideC, 2);

            //Calculation output

            Console.WriteLine("The length of side C = " + SideC);


            Console.ReadKey();
            
        }
    }
}
